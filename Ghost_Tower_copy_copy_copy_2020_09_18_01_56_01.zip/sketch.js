var ghost,ghost_Image
var door,door_Image
var tower,tower_Image
var climber,climber_Image

function preload () {
tower_Image=loadImage("tower.png");
door_Image=loadImage("door.png");
ghost_Image=loadImage("ghost-standing.png");
  climber_Image=loadImage("climber.png")

}
function setup() {
createCanvas(600,600);
tower=createSprite(300,300);
  tower.addImage(tower_Image);
  tower.velocityY=3;
  ghost=createSprite(300,300); 
ghost.addImage(ghost_Image);
  ghost.scale=0.4;

}


function draw () {
background("black");

  
  if (tower.y > 400){
   tower.y=300;
    }
  
  if (keyDown("space")){
  ghost.velocityY=-10;
  }
  ghost.velocityY = ghost.velocityY + 0.8
  
  createDoor();
drawSprites();
  
}

function createDoor () {
 if (frameCount % 240 === 0) {
    door = createSprite(200,-50);
    door.x = Math.round(random(120,400));
    door.addImage(door_Image);
    door.scale = 0.5;
    door.velocity.Y = 3;
 }
}
